import React, { useState, useEffect, useCallback } from "react";
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Toaster } from "./components/ui/sonner";
import Landing from "./components/Landing";
import Documentation from "./components/pages/Documentation";
import APIReference from "./components/pages/APIReference";
import SmartContract from "./components/pages/SmartContract";
import PrivacyPolicy from "./components/pages/PrivacyPolicy";
import TermsOfService from "./components/pages/TermsOfService";
import CookiePolicy from "./components/pages/CookiePolicy";
import CandidateDashboard from "./components/candidate/Dashboard";
import RecruiterDashboard from "./components/recruiter/Dashboard";
import "./App.css";
import "./index.css";

// Inner component that has access to useNavigate
function AppContent() {
  const navigate = useNavigate();
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Validate user has required fields
        if (parsed && parsed.role && parsed.email) {
          return parsed;
        }
      } catch (e) {
        localStorage.removeItem('user');
      }
    }
    return null;
  });

  // Safe setUser that handles both direct user objects and updater functions
  const handleSetUser = useCallback((userData) => {
    // If it's a function (from setUser(prev => ...)), call it with current user to get the new user object
    if (typeof userData === 'function') {
      setUser(prev => {
        const updated = userData(prev);
        // Only validate and persist if we got a valid user object
        if (updated && updated.role && updated.email) {
          localStorage.setItem('user', JSON.stringify(updated));
          return updated;
        } else {
          // Invalid user object, clear and redirect
          localStorage.removeItem('user');
          navigate('/');
          return null;
        }
      });
    } else {
      // Direct user object
      if (userData && userData.role && userData.email) {
        setUser(userData);
      } else {
        // If invalid user data, clear and redirect to home
        setUser(null);
        localStorage.removeItem('user');
        navigate('/');
      }
    }
  }, [navigate]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  return (
    <Routes>
      <Route path="/" element={user && user.role ? <Navigate to={`/${user.role}`} /> : <Landing setUser={handleSetUser} />} />
      <Route path="/documentation" element={<Documentation />} />
      <Route path="/api-reference" element={<APIReference />} />
      <Route path="/smart-contract" element={<SmartContract />} />
      <Route path="/privacy-policy" element={<PrivacyPolicy />} />
      <Route path="/terms-of-service" element={<TermsOfService />} />
      <Route path="/cookie-policy" element={<CookiePolicy />} />
      <Route 
        path="/candidate/*" 
        element={user?.role === 'candidate' ? <CandidateDashboard user={user} setUser={handleSetUser} /> : <Navigate to="/" />} 
      />
      <Route 
        path="/recruiter/*" 
        element={user?.role === 'recruiter' ? <RecruiterDashboard user={user} setUser={handleSetUser} /> : <Navigate to="/" />} 
      />
    </Routes>
  );
}

function App() {
  return (
    <ThemeProvider>
      <div className="App min-h-screen bg-background text-foreground">
        <BrowserRouter>
          <AppContent />
        </BrowserRouter>
        <Toaster position="top-right" />
      </div>
    </ThemeProvider>
  );
}

export default App;
